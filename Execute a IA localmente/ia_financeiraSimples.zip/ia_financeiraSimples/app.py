from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import fitz  # PyMuPDF
import google.generativeai as google
import os
import matplotlib.pyplot as plt
import uuid

app = Flask(__name__)
CORS(app)
GOOGLE_API_KEY = "AIzaSyB9D-tFLHgCR6t35Bzpe7l0Qyyb-NYv-Sg"
google.configure(api_key=GOOGLE_API_KEY)

model = google.GenerativeModel("gemini-1.5-flash")
chat = model.start_chat(history=[])

INSTRUCOES = """
Você é uma IA focada exclusivamente em Educação Financeira.
Ensine com clareza, objetividade e postura profissional. Nunca responda temas fora desse escopo.

──── MISSÃO ────
Ensinar finanças pessoais de forma técnica e direta, respondendo sobre:

* Orçamento
* Gastos
* Dívidas
* Aposentadoria
* Investimentos básicos
* Reserva de emergência
* caso o usuario peça para que você gere uma tabela gere 
* caso ele queira exportar disponibilize o dowlonad 

Sem consultoria ou indicação de produtos.

──── REGRAS ────

1. Responda só sobre educação financeira. Para outros temas, diga: "Desculpe, só respondo sobre educação financeira."

2. Use linguagem simples e direta. Evite jargões ou explique-os brevemente.

3. Não analise casos pessoais nem recomende instituições.

4. Dúvidas fora do escopo: "Só posso ajudar com educação financeira. Vamos falar de orçamento ou investimentos?"

──── EXEMPLOS ────
Usuário: "Como guardar dinheiro?"
Resposta: "Use a regra 50-30-20: 50% necessidades, 30% desejos, 20% poupança/investimento."

Usuário: "Investimentos seguros?"
Resposta: "Tesouro Selic, CDBs de grandes bancos e poupança são opções com baixo risco."

──── FINAL ──── Baseie-se em fontes confiáveis. e nos pdfs que te damos no Se não souber, diga: "Não tenho dados suficientes. Consulte o Banco Central ou Serasa Ensina."
  caso a IA pergunte o  nomed dos seus criadores você deve responder: Natan Felipe e Cecilia Elen 

"""

chat.send_message(INSTRUCOES)

def extrair_texto_pdf(pdf_path):
    texto = ""
    with fitz.open(pdf_path) as pdf:
        for pagina in pdf:
            texto += pagina.get_text()
    return texto

conteudo_total = ""

def carregar_pdfs_da_pasta():
    texto_acumulado = ""
    pasta_pdfs = "pdf's"
    if os.path.exists(pasta_pdfs):
        arquivos_pdf = [f for f in os.listdir(pasta_pdfs) if f.lower().endswith('.pdf')]
        for nome_arquivo in arquivos_pdf:
            caminho_pdf = os.path.join(pasta_pdfs, nome_arquivo)
            texto_acumulado += extrair_texto_pdf(caminho_pdf) + "\n"
    return texto_acumulado

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/pergunta', methods=['POST'])
def pergunta():
    global conteudo_total
    pergunta_usuario = request.json["mensagem"]
    prompt = f"{pergunta_usuario}\n\n{conteudo_total[:4000]}"
    resposta = chat.send_message(prompt)
    resposta_formatada = resposta.text.replace(". ", ".\n")
    return jsonify({"resposta": resposta_formatada})

@app.route('/orcamento', methods=['GET', 'POST'])
def orcamento():
    if request.method == 'POST':
        ganhos = float(request.form['ganhos'])
        gastos = float(request.form['gastos'])
        saldo = ganhos - gastos
        return render_template("orcamento.html", saldo=saldo, ganhos=ganhos, gastos=gastos)
    return render_template("orcamento.html")

@app.route('/grafico', methods=['GET', 'POST'])
def grafico():
    if request.method == 'POST':
        categorias = request.form.getlist('categoria')
        valores = request.form.getlist('valor')
        valores = [float(v) for v in valores]

        fig, ax = plt.subplots()
        ax.pie(valores, labels=categorias, autopct='%1.1f%%')
        ax.set_title("Distribuição de Despesas")

        nome_arquivo = f"static/grafico_{uuid.uuid4().hex}.png"
        plt.savefig(nome_arquivo)
        plt.close()
        return render_template("grafico.html", imagem=nome_arquivo)

    return render_template("grafico.html")

if __name__ == '__main__':
    os.makedirs("pdfs", exist_ok=True)
    conteudo_total = carregar_pdfs_da_pasta()
    app.run(debug=True)